<?php
header("Access-Control-Allow-Origin");
header("Application/json");

$servername = "192.168.43.42";
$username = "jeo";
$password = "";
$dbname = "parking";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
?>